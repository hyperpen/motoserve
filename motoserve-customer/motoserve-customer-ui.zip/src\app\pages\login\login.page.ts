import { ChangeDetectorRef, Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { IonButton, IonContent, IonInput, IonText } from '@ionic/angular';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, IonButton, IonContent, IonInput, IonText],
  template: `
    <ion-content class="ion-padding">
      <div class="login-box">
        <h1>MotoServe</h1>
        <p>Customer Login</p>

        <form (ngSubmit)="submit()">
          <ion-input
            label="Email"
            labelPlacement="stacked"
            fill="outline"
            type="email"
            name="email"
            [(ngModel)]="email"
            required>
          </ion-input>

          <ion-input
            label="Password"
            labelPlacement="stacked"
            fill="outline"
            type="password"
            name="password"
            [(ngModel)]="password"
            required>
          </ion-input>

          @if (errorMessage) {
            <ion-text color="danger">
              <p>{{ errorMessage }}</p>
            </ion-text>
          }

          <ion-button
            expand="block"
            type="submit"
            [disabled]="loading">
            {{ loading ? 'Logging in...' : 'Login' }}
          </ion-button>
        </form>
      </div>
    </ion-content>
  `,
  styles: [`
    .login-box {
      max-width: 420px;
      margin: 15vh auto 0;
    }

    ion-input {
      margin: 16px 0;
    }
  `],
})
export class LoginPage {
  private auth = inject(AuthService);
  private router = inject(Router);
  private cdr = inject(ChangeDetectorRef);

  email = '';
  password = '';
  loading = false;
  errorMessage = '';

  async submit() {
    if (!this.email || !this.password || this.loading) return;

    this.loading = true;
    this.errorMessage = '';

    try {
      await this.auth.login(this.email, this.password);

      await this.router.navigateByUrl('/tabs/tab1', {
        replaceUrl: true,
      });
    } catch (error) {
      if (error instanceof HttpErrorResponse) {
        this.errorMessage =
          error.status === 0
            ? 'Hindi maabot ang Laravel API. Tingnan ang Network/Console.'
            : error.error?.errors?.email?.[0] ??
              error.error?.message ??
              `API error (${error.status}).`;
      } else {
        this.errorMessage =
          error instanceof Error
            ? error.message
            : 'Nag-error pagkatapos sumagot ang API.';
      }
    } finally {
      this.loading = false;
      this.cdr.markForCheck();
    }
  }
}