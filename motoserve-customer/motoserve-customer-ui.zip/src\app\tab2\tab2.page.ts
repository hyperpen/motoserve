import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import {
  IonButton,
  IonCard,
  IonCardContent,
  IonCardHeader,
  IonCardTitle,
  IonContent,
  IonHeader,
  IonInput,
  IonText,
  IonTitle,
  IonToolbar,
} from '@ionic/angular';

import { CustomerApiService } from '../services/customer-api.service';

interface Motorcycle {
  id: number;
  brand: string;
  model: string;
  year: number | null;
  plate_number: string | null;
  color: string | null;
}

interface MotorcycleForm {
  brand: string;
  model: string;
  year: string | number;
  plate_number: string;
  color: string;
}

interface MotorcycleResponse {
  message: string;
  motorcycle: Motorcycle;
}

@Component({
  selector: 'app-tab2',
  standalone: true,
  imports: [
    FormsModule,
    IonButton,
    IonCard,
    IonCardContent,
    IonCardHeader,
    IonCardTitle,
    IonContent,
    IonHeader,
    IonInput,
    IonText,
    IonTitle,
    IonToolbar,
  ],
  template: `
    <ion-header>
      <ion-toolbar>
        <ion-title>My Motorcycles</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <h2>{{ editingId() === null ? 'Add Motorcycle' : 'Edit Motorcycle' }}</h2>

      <form (ngSubmit)="save()">
        <ion-input
          label="Brand"
          labelPlacement="stacked"
          fill="outline"
          name="brand"
          [(ngModel)]="form.brand"
          maxlength="100"
          required>
        </ion-input>

        <ion-input
          label="Model"
          labelPlacement="stacked"
          fill="outline"
          name="model"
          [(ngModel)]="form.model"
          maxlength="100"
          required>
        </ion-input>

        <ion-input
          label="Year (optional)"
          labelPlacement="stacked"
          fill="outline"
          type="number"
          name="year"
          [(ngModel)]="form.year"
          min="1950"
          [max]="currentYear">
        </ion-input>

        <ion-input
          label="Plate Number (optional)"
          labelPlacement="stacked"
          fill="outline"
          name="plate_number"
          [(ngModel)]="form.plate_number"
          maxlength="30">
        </ion-input>

        <ion-input
          label="Color (optional)"
          labelPlacement="stacked"
          fill="outline"
          name="color"
          [(ngModel)]="form.color"
          maxlength="50">
        </ion-input>

        <ion-button expand="block" type="submit" [disabled]="saving()">
          {{ saving() ? 'Saving...' : editingId() === null ? 'Add Motorcycle' : 'Save Changes' }}
        </ion-button>

        @if (editingId() !== null) {
          <ion-button expand="block" fill="clear" type="button"
            (click)="cancelEdit()">
            Cancel Edit
          </ion-button>
        }
      </form>

      @if (successMessage()) {
        <ion-text color="success">
          <p>{{ successMessage() }}</p>
        </ion-text>
      }

      @if (errorMessage()) {
        <ion-text color="danger">
          <p>{{ errorMessage() }}</p>
        </ion-text>
      }

      <h2>Your Motorcycles</h2>

      <ion-button fill="outline" (click)="loadMotorcycles()">
        Refresh
      </ion-button>

      @if (loading()) {
        <p>Loading motorcycles...</p>
      } @else if (motorcycles().length === 0) {
        <p>No motorcycles added yet.</p>
      } @else {
        @for (motorcycle of motorcycles(); track motorcycle.id) {
          <ion-card>
            <ion-card-header>
              <ion-card-title>
                {{ motorcycle.brand }} {{ motorcycle.model }}
              </ion-card-title>
            </ion-card-header>

            <ion-card-content>
              <p>Year: {{ motorcycle.year ?? 'Not specified' }}</p>
              <p>Plate: {{ motorcycle.plate_number || 'Not specified' }}</p>
              <p>Color: {{ motorcycle.color || 'Not specified' }}</p>

              <ion-button fill="outline" (click)="edit(motorcycle)">
                Edit
              </ion-button>

              <ion-button color="danger" fill="outline"
                [disabled]="deletingId() === motorcycle.id"
                (click)="remove(motorcycle)">
                {{ deletingId() === motorcycle.id ? 'Deleting...' : 'Delete' }}
              </ion-button>
            </ion-card-content>
          </ion-card>
        }
      }
    </ion-content>
  `,
  styles: [`
    ion-input {
      margin: 14px 0;
    }

    ion-card {
      margin: 16px 0;
    }
  `],
})
export class Tab2Page implements OnInit {
  private api = inject(CustomerApiService);

  readonly currentYear = new Date().getFullYear();

  motorcycles = signal<Motorcycle[]>([]);
  loading = signal(true);
  saving = signal(false);
  deletingId = signal<number | null>(null);
  editingId = signal<number | null>(null);
  errorMessage = signal('');
  successMessage = signal('');

  form: MotorcycleForm = this.emptyForm();

  ngOnInit() {
    void this.loadMotorcycles();
  }

  async loadMotorcycles() {
    this.loading.set(true);
    this.errorMessage.set('');

    try {
      const response = await firstValueFrom(
        this.api.get<{ motorcycles: Motorcycle[] }>('motorcycles')
      );
      this.motorcycles.set(response.motorcycles);
    } catch (error) {
      this.errorMessage.set(this.describeError(error));
    } finally {
      this.loading.set(false);
    }
  }

  async save() {
    if (this.saving()) return;

    const brand = this.form.brand.trim();
    const model = this.form.model.trim();
    const yearText = String(this.form.year ?? '').trim();

    if (!brand || !model) {
      this.errorMessage.set('Brand and model are required.');
      return;
    }

    const year = yearText === '' ? null : Number(yearText);

    if (
      year !== null &&
      (!Number.isInteger(year) || year < 1950 || year > this.currentYear)
    ) {
      this.errorMessage.set(
        `Year must be between 1950 and ${this.currentYear}.`
      );
      return;
    }

    const body = {
      brand,
      model,
      year,
      plate_number: this.form.plate_number.trim() || null,
      color: this.form.color.trim() || null,
    };

    this.saving.set(true);
    this.errorMessage.set('');
    this.successMessage.set('');

    try {
      const id = this.editingId();

      const response = id === null
        ? await firstValueFrom(
            this.api.post<MotorcycleResponse>('motorcycles', body)
          )
        : await firstValueFrom(
            this.api.put<MotorcycleResponse>(`motorcycles/${id}`, body)
          );

      this.cancelEdit();
      await this.loadMotorcycles();
      this.successMessage.set(response.message);
    } catch (error) {
      this.errorMessage.set(this.describeError(error));
    } finally {
      this.saving.set(false);
    }
  }

  edit(motorcycle: Motorcycle) {
    this.editingId.set(motorcycle.id);
    this.form = {
      brand: motorcycle.brand,
      model: motorcycle.model,
      year: motorcycle.year?.toString() ?? '',
      plate_number: motorcycle.plate_number ?? '',
      color: motorcycle.color ?? '',
    };
    this.errorMessage.set('');
    this.successMessage.set('');
  }

  cancelEdit() {
    this.editingId.set(null);
    this.form = this.emptyForm();
  }

  async remove(motorcycle: Motorcycle) {
    if (
      !window.confirm(
        `Delete ${motorcycle.brand} ${motorcycle.model}?`
      )
    ) {
      return;
    }

    this.deletingId.set(motorcycle.id);
    this.errorMessage.set('');
    this.successMessage.set('');

    try {
      const response = await firstValueFrom(
        this.api.delete<{ message: string }>(
          `motorcycles/${motorcycle.id}`
        )
      );

      if (this.editingId() === motorcycle.id) {
        this.cancelEdit();
      }

      await this.loadMotorcycles();
      this.successMessage.set(response.message);
    } catch (error) {
      this.errorMessage.set(this.describeError(error));
    } finally {
      this.deletingId.set(null);
    }
  }

  private emptyForm(): MotorcycleForm {
    return {
      brand: '',
      model: '',
      year: '',
      plate_number: '',
      color: '',
    };
  }

  private describeError(error: unknown): string {
    if (error instanceof HttpErrorResponse) {
      if (error.status === 0) {
        return 'Cannot connect to MotoServe API.';
      }

      const errors = error.error?.errors as
        Record<string, string[]> | undefined;

      return (
        (errors ? Object.values(errors)[0]?.[0] : undefined) ??
        error.error?.message ??
        `API error (${error.status}).`
      );
    }

    return error instanceof Error
      ? error.message
      : 'Something went wrong.';
  }
}