import { Component, OnInit, inject, signal } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import {
  IonButton,
  IonContent,
  IonHeader,
  IonText,
  IonTitle,
  IonToolbar,
} from '@ionic/angular';

import { Customer } from '../services/auth.service';
import { CustomerApiService } from '../services/customer-api.service';

@Component({
  selector: 'app-tab1',
  standalone: true,
  imports: [
    IonButton,
    IonContent,
    IonHeader,
    IonText,
    IonTitle,
    IonToolbar,
  ],
  template: `
    <ion-header>
      <ion-toolbar>
        <ion-title>MotoServe</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <h1>Customer Home</h1>

      @if (loading()) {
        <p>Loading account...</p>
      } @else if (errorMessage()) {
        <ion-text color="danger">
          <p>{{ errorMessage() }}</p>
        </ion-text>
        <ion-button (click)="loadProfile()">Retry</ion-button>
      } @else if (customer(); as user) {
        <h2>Welcome, {{ user.name }}!</h2>
        <p>Email: {{ user.email }}</p>
        <p>Phone: {{ user.phone }}</p>
      }
    </ion-content>
  `,
})
export class Tab1Page implements OnInit {
  private api = inject(CustomerApiService);

  customer = signal<Customer | null>(null);
  loading = signal(true);
  errorMessage = signal('');

  ngOnInit() {
    void this.loadProfile();
  }

  async loadProfile() {
    this.loading.set(true);
    this.errorMessage.set('');

    try {
      const user = await firstValueFrom(
        this.api.get<Customer>('me')
      );
      this.customer.set(user);
    } catch (error) {
      if (error instanceof HttpErrorResponse) {
        this.errorMessage.set(
          error.status === 401
            ? 'Session expired. Please log in again.'
            : error.error?.message ?? `API error (${error.status}).`
        );
      } else {
        this.errorMessage.set('Cannot load customer account.');
      }
    } finally {
      this.loading.set(false);
    }
  }
}