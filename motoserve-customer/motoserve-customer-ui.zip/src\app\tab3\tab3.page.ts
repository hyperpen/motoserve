import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import {
  IonButton,
  IonCard,
  IonCardContent,
  IonCardHeader,
  IonCardTitle,
  IonContent,
  IonHeader,
  IonSelect,
  IonSelectOption,
  IonText,
  IonTextarea,
  IonTitle,
  IonToolbar,
} from '@ionic/angular';

import { CustomerApiService } from '../services/customer-api.service';

interface Motorcycle {
  id: number;
  brand: string;
  model: string;
  plate_number: string | null;
}

interface Service {
  id: number;
  name: string;
}

interface Mechanic {
  id: number;
  name: string;
}

interface Appointment {
  id: number;
  appointment_number: string;
  appointment_date: string;
  appointment_time: string;
  status: string;
  problem_description: string | null;
  motorcycle: Motorcycle | null;
  service: Service | null;
  mechanic: Mechanic | null;
}

@Component({
  selector: 'app-tab3',
  standalone: true,
  imports: [
    FormsModule,
    IonButton,
    IonCard,
    IonCardContent,
    IonCardHeader,
    IonCardTitle,
    IonContent,
    IonHeader,
    IonSelect,
    IonSelectOption,
    IonText,
    IonTextarea,
    IonTitle,
    IonToolbar,
  ],
  template: `
    <ion-header>
      <ion-toolbar>
        <ion-title>Appointments</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <h2>Book a Service</h2>

      @if (loading()) {
        <p>Loading booking options...</p>
      } @else {
        @if (motorcycles().length === 0) {
          <p>Add a motorcycle before booking an appointment.</p>
          <ion-button href="/tabs/tab2">
            Go to Motorcycles
          </ion-button>
        } @else if (services().length === 0) {
          <p>No services are available right now.</p>
        } @else {
          <form (ngSubmit)="book()">
            <ion-select
              label="Motorcycle"
              labelPlacement="stacked"
              fill="outline"
              placeholder="Select motorcycle"
              name="motorcycle_id"
              [(ngModel)]="motorcycleId">
              @for (motorcycle of motorcycles(); track motorcycle.id) {
                <ion-select-option [value]="motorcycle.id">
                  {{ motorcycle.brand }} {{ motorcycle.model }}
                </ion-select-option>
              }
            </ion-select>

            <ion-select
              label="Service"
              labelPlacement="stacked"
              fill="outline"
              placeholder="Select service"
              name="service_id"
              [(ngModel)]="serviceId">
              @for (service of services(); track service.id) {
                <ion-select-option [value]="service.id">
                  {{ service.name }}
                </ion-select-option>
              }
            </ion-select>

            <label class="field-label" for="appointment-date">
              Appointment Date
            </label>
            <input
              id="appointment-date"
              class="date-time-input"
              type="date"
              name="appointment_date"
              [min]="today"
              [(ngModel)]="appointmentDate"
              required>

            <label class="field-label" for="appointment-time">
              Appointment Time
            </label>
            <input
              id="appointment-time"
              class="date-time-input"
              type="time"
              name="appointment_time"
              [(ngModel)]="appointmentTime"
              required>

            <ion-textarea
              label="Problem Description (optional)"
              labelPlacement="stacked"
              fill="outline"
              name="problem_description"
              [(ngModel)]="problemDescription"
              maxlength="2000"
              [autoGrow]="true">
            </ion-textarea>

            <ion-button
              expand="block"
              type="submit"
              [disabled]="saving()">
              {{ saving() ? 'Booking...' : 'Book Appointment' }}
            </ion-button>
          </form>
        }
      }

      @if (successMessage()) {
        <ion-text color="success">
          <p>{{ successMessage() }}</p>
        </ion-text>
      }

      @if (errorMessage()) {
        <ion-text color="danger">
          <p>{{ errorMessage() }}</p>
        </ion-text>
      }

      <h2>My Appointments</h2>

      <ion-button fill="outline" (click)="loadData()">
        Refresh
      </ion-button>

      @if (loading()) {
        <p>Loading appointments...</p>
      } @else if (appointments().length === 0) {
        <p>No appointments yet.</p>
      } @else {
        @for (appointment of appointments(); track appointment.id) {
          <ion-card>
            <ion-card-header>
              <ion-card-title>
                {{ appointment.appointment_number }}
              </ion-card-title>
            </ion-card-header>

            <ion-card-content>
              <p>
                Service:
                {{ appointment.service?.name || 'Unavailable' }}
              </p>
              <p>
                Motorcycle:
                {{ appointment.motorcycle?.brand || '' }}
                {{ appointment.motorcycle?.model || 'Unavailable' }}
              </p>
              <p>
                Date: {{ appointment.appointment_date.slice(0, 10) }}
              </p>
              <p>
                Time: {{ appointment.appointment_time.slice(0, 5) }}
              </p>
              <p>Status: {{ appointment.status }}</p>

              @if (appointment.mechanic) {
                <p>Mechanic: {{ appointment.mechanic.name }}</p>
              }

              @if (appointment.problem_description) {
                <p>
                  Problem: {{ appointment.problem_description }}
                </p>
              }

              @if (canCancel(appointment)) {
                <ion-button
                  color="danger"
                  fill="outline"
                  [disabled]="cancellingId() === appointment.id"
                  (click)="cancel(appointment)">
                  {{
                    cancellingId() === appointment.id
                      ? 'Cancelling...'
                      : 'Cancel Appointment'
                  }}
                </ion-button>
              }
            </ion-card-content>
          </ion-card>
        }
      }
    </ion-content>
  `,
  styles: [`
    ion-select,
    ion-textarea {
      margin: 14px 0;
    }

    .field-label {
      display: block;
      margin-top: 16px;
      margin-bottom: 6px;
    }

    .date-time-input {
      display: block;
      box-sizing: border-box;
      width: 100%;
      padding: 14px;
      color: inherit;
      background: transparent;
      border: 1px solid #777;
      border-radius: 5px;
      font: inherit;
    }

    ion-card {
      margin: 16px 0;
    }
  `],
})
export class Tab3Page implements OnInit {
  private api = inject(CustomerApiService);

  motorcycles = signal<Motorcycle[]>([]);
  services = signal<Service[]>([]);
  appointments = signal<Appointment[]>([]);

  loading = signal(true);
  saving = signal(false);
  cancellingId = signal<number | null>(null);
  successMessage = signal('');
  errorMessage = signal('');

  motorcycleId: number | null = null;
  serviceId: number | null = null;
  appointmentDate = '';
  appointmentTime = '';
  problemDescription = '';

  today = this.localDate();

  ngOnInit() {
    void this.loadData();
  }

  async loadData() {
    this.loading.set(true);
    this.errorMessage.set('');

    try {
      const [motorcycles, services, appointments] =
        await Promise.all([
          firstValueFrom(
            this.api.get<{ motorcycles: Motorcycle[] }>(
              'motorcycles'
            )
          ),
          firstValueFrom(
            this.api.get<{ services: Service[] }>('services')
          ),
          firstValueFrom(
            this.api.get<{ appointments: Appointment[] }>(
              'appointments'
            )
          ),
        ]);

      this.motorcycles.set(motorcycles.motorcycles);
      this.services.set(services.services);
      this.appointments.set(appointments.appointments);
    } catch (error) {
      this.errorMessage.set(this.describeError(error));
    } finally {
      this.loading.set(false);
    }
  }

  async book() {
    if (this.saving()) return;

    if (
      this.motorcycleId === null ||
      this.serviceId === null ||
      !this.appointmentDate ||
      !this.appointmentTime
    ) {
      this.errorMessage.set(
        'Select a motorcycle, service, date, and time.'
      );
      return;
    }

    this.saving.set(true);
    this.errorMessage.set('');
    this.successMessage.set('');

    try {
      const response = await firstValueFrom(
        this.api.post<{ message: string; appointment: Appointment }>(
          'appointments',
          {
            motorcycle_id: this.motorcycleId,
            service_id: this.serviceId,
            appointment_date: this.appointmentDate,
            appointment_time: this.appointmentTime,
            problem_description:
              this.problemDescription.trim() || null,
          }
        )
      );

      this.appointmentDate = '';
      this.appointmentTime = '';
      this.problemDescription = '';

      await this.loadData();
      this.successMessage.set(response.message);
    } catch (error) {
      this.errorMessage.set(this.describeError(error));
    } finally {
      this.saving.set(false);
    }
  }

  canCancel(appointment: Appointment): boolean {
    return [
      'pending',
      'confirmed',
      'mechanic_assigned',
    ].includes(appointment.status);
  }

  async cancel(appointment: Appointment) {
    if (
      !window.confirm(
        `Cancel appointment ${appointment.appointment_number}?`
      )
    ) {
      return;
    }

    this.cancellingId.set(appointment.id);
    this.errorMessage.set('');
    this.successMessage.set('');

    try {
      const response = await firstValueFrom(
        this.api.patch<{ message: string }>(
          `appointments/${appointment.id}/cancel`,
          {}
        )
      );

      await this.loadData();
      this.successMessage.set(response.message);
    } catch (error) {
      this.errorMessage.set(this.describeError(error));
    } finally {
      this.cancellingId.set(null);
    }
  }

  private localDate(): string {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');

    return `${year}-${month}-${day}`;
  }

  private describeError(error: unknown): string {
    if (error instanceof HttpErrorResponse) {
      if (error.status === 0) {
        return 'Cannot connect to MotoServe API.';
      }

      const errors = error.error?.errors as
        Record<string, string[]> | undefined;

      return (
        (errors ? Object.values(errors)[0]?.[0] : undefined) ??
        error.error?.message ??
        `API error (${error.status}).`
      );
    }

    return error instanceof Error
      ? error.message
      : 'Something went wrong.';
  }
}