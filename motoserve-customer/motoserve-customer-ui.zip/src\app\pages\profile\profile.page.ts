import {
  ChangeDetectorRef,
  Component,
  OnInit,
  inject,
  signal,
} from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import {
  IonButton,
  IonCard,
  IonCardContent,
  IonCardHeader,
  IonCardTitle,
  IonContent,
  IonHeader,
  IonText,
  IonTitle,
  IonToolbar,
} from '@ionic/angular';

import {
  AuthService,
  Customer,
} from '../../services/auth.service';
import { CartService } from '../../services/cart.service';
import { CustomerApiService } from '../../services/customer-api.service';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [
    IonButton,
    IonCard,
    IonCardContent,
    IonCardHeader,
    IonCardTitle,
    IonContent,
    IonHeader,
    IonText,
    IonTitle,
    IonToolbar,
  ],
  template: `
    <ion-header>
      <ion-toolbar>
        <ion-title>My Profile</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      @if (errorMessage()) {
        <ion-text color="danger">
          <p>{{ errorMessage() }}</p>
        </ion-text>
      }

      @if (loading()) {
        <p>Loading profile...</p>
      } @else if (customer(); as user) {
        <ion-card>
          <ion-card-header>
            <ion-card-title>{{ user.name }}</ion-card-title>
          </ion-card-header>

          <ion-card-content>
            <p>Email: {{ user.email }}</p>
            <p>Phone: {{ user.phone || 'Not provided' }}</p>
            <p>Account status: {{ user.status }}</p>
          </ion-card-content>
        </ion-card>
      }

      <ion-button
        expand="block"
        fill="outline"
        [disabled]="loading()"
        (click)="loadProfile()">
        Refresh Profile
      </ion-button>

      <ion-button
        expand="block"
        color="danger"
        [disabled]="loggingOut()"
        (click)="logout()">
        {{ loggingOut() ? 'Logging out...' : 'Logout' }}
      </ion-button>
    </ion-content>
  `,
  styles: [`
    ion-card {
      margin: 16px 0 24px;
    }

    ion-button {
      margin-top: 12px;
    }
  `],
})
export class ProfilePage implements OnInit {
  private api = inject(CustomerApiService);
  private auth = inject(AuthService);
  private cart = inject(CartService);
  private router = inject(Router);
  private cdr = inject(ChangeDetectorRef);

  customer = signal<Customer | null>(null);
  loading = signal(true);
  loggingOut = signal(false);
  errorMessage = signal('');

  ngOnInit(): void {
    void this.loadProfile();
  }

  async loadProfile(): Promise<void> {
    this.loading.set(true);
    this.errorMessage.set('');

    try {
      const user = await firstValueFrom(
        this.api.get<Customer>('me')
      );

      this.customer.set(user);
    } catch (error) {
      this.errorMessage.set(this.describeError(error));
    } finally {
      this.loading.set(false);
      this.cdr.markForCheck();
    }
  }

  async logout(): Promise<void> {
    if (this.loggingOut()) return;

    this.loggingOut.set(true);
    this.errorMessage.set('');

    try {
      await firstValueFrom(
        this.api.post<{ message: string }>('logout', {})
      );
    } catch (error) {
      // Kung expired na ang token, puwede pa ring i-clear
      // ang local session at bumalik sa Login.
      if (
        !(error instanceof HttpErrorResponse) ||
        error.status !== 401
      ) {
        this.errorMessage.set(this.describeError(error));
        this.loggingOut.set(false);
        this.cdr.markForCheck();
        return;
      }
    }

    try {
      await this.cart.clear();
      await this.auth.clearToken();

      await this.router.navigateByUrl('/login', {
        replaceUrl: true,
      });
    } catch {
      this.errorMessage.set('Could not clear the saved session.');
    } finally {
      this.loggingOut.set(false);
      this.cdr.markForCheck();
    }
  }

  private describeError(error: unknown): string {
    if (error instanceof HttpErrorResponse) {
      if (error.status === 0) {
        return 'Cannot connect to MotoServe API.';
      }

      return error.error?.message ??
        `Request failed (${error.status}).`;
    }

    return 'Something went wrong.';
  }
}