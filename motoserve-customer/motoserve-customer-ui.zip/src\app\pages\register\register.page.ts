import { ChangeDetectorRef, Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { IonButton, IonContent, IonInput, IonText } from '@ionic/angular';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [FormsModule, IonButton, IonContent, IonInput, IonText],
  template: `
    <ion-content class="ion-padding">
      <div class="register-box">
        <h1>Create Account</h1>
        <p>MotoServe Customer</p>

        <form (ngSubmit)="submit()">
          <ion-input
            label="Full Name"
            labelPlacement="stacked"
            fill="outline"
            name="name"
            [(ngModel)]="name"
            required>
          </ion-input>

          <ion-input
            label="Email"
            labelPlacement="stacked"
            fill="outline"
            type="email"
            name="email"
            [(ngModel)]="email"
            required>
          </ion-input>

          <ion-input
            label="Phone Number"
            labelPlacement="stacked"
            fill="outline"
            type="tel"
            name="phone"
            [(ngModel)]="phone"
            required>
          </ion-input>

          <ion-input
            label="Password"
            labelPlacement="stacked"
            fill="outline"
            type="password"
            name="password"
            [(ngModel)]="password"
            required>
          </ion-input>

          <ion-input
            label="Confirm Password"
            labelPlacement="stacked"
            fill="outline"
            type="password"
            name="confirmation"
            [(ngModel)]="confirmation"
            required>
          </ion-input>

          @if (errorMessage) {
            <ion-text color="danger">
              <p>{{ errorMessage }}</p>
            </ion-text>
          }

          <ion-button expand="block" type="submit" [disabled]="loading">
            {{ loading ? 'Creating account...' : 'Register' }}
          </ion-button>

          <ion-button
            expand="block"
            fill="clear"
            type="button"
            (click)="goLogin()">
            Already have an account? Login
          </ion-button>
        </form>
      </div>
    </ion-content>
  `,
  styles: [`
    .register-box {
      max-width: 420px;
      margin: 8vh auto 0;
    }

    ion-input {
      margin: 14px 0;
    }
  `],
})
export class RegisterPage {
  private auth = inject(AuthService);
  private router = inject(Router);
  private cdr = inject(ChangeDetectorRef);

  name = '';
  email = '';
  phone = '';
  password = '';
  confirmation = '';
  loading = false;
  errorMessage = '';

  async submit() {
    if (this.loading) return;

    if (
      !this.name ||
      !this.email ||
      !this.phone ||
      !this.password ||
      !this.confirmation
    ) {
      this.errorMessage = 'Please complete all fields.';
      return;
    }

    if (this.password !== this.confirmation) {
      this.errorMessage = 'Passwords do not match.';
      return;
    }

    this.loading = true;
    this.errorMessage = '';

    try {
      await this.auth.register({
        name: this.name,
        email: this.email,
        phone: this.phone,
        password: this.password,
        password_confirmation: this.confirmation,
      });

      await this.router.navigateByUrl('/tabs/tab1', {
        replaceUrl: true,
      });
    } catch (error) {
      const response = error as HttpErrorResponse;
      const errors = response.error?.errors as
        Record<string, string[]> | undefined;

      this.errorMessage =
        (errors ? Object.values(errors)[0]?.[0] : undefined) ??
        response.error?.message ??
        'Cannot connect to MotoServe API.';
    } finally {
      this.loading = false;
      this.cdr.markForCheck();
    }
  }

  goLogin() {
    this.router.navigateByUrl('/login');
  }
}